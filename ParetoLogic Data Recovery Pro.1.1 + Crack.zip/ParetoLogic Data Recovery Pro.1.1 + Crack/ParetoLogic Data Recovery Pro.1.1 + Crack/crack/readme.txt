

     Step 1: Install the program
     Step 2: Backup the original executable
     Step 3: Replace with the cracked executable
     Step 4: Run the application.
          
     *iMPORTANT: Set PLDataRecovery.exe to read-only to avoid self update!
          
